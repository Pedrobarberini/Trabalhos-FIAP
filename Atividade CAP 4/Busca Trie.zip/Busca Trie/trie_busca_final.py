"""
Busca de registros por prefixo usando Trie.

Os registros (módulos, sensores, comandos e alertas) ficam na tabela
registros.json. 
Ao iniciar, o programa lê o JSON e monta a Trie em memória;
cada novo cadastro é gravado no JSON e inserido na Trie ao mesmo tempo.

A busca por prefixo (opção 5) é "ao vivo": as sugestões aparecem a cada tecla
digitada, sem Enter. 
Em ambientes sem terminal de verdade (IDLE, alguns consoles
de IDE, pipes), ela cai automaticamente para a busca com Enter.
"""
from __future__ import annotations

import codecs
import json
import os
import shutil
import sys
import tempfile
import unicodedata
from pathlib import Path

# Leitura de teclas sem Enter: msvcrt no Windows, termios/tty no Linux e macOS.
try:
    import msvcrt
    termios = tty = None
except ImportError:
    msvcrt = None
    try:
        import termios
        import tty
    except ImportError:  # ambiente sem nenhum dos dois: a busca usa Enter
        termios = tty = None

TIPOS = ("modulo", "sensor", "comando", "alerta")
ROTULOS = {"modulo": "Módulo", "sensor": "Sensor", "comando": "Comando", "alerta": "Alerta"}
ARQUIVO_PADRAO = Path(__file__).with_name("registros.json")


def normalizar(texto: str) -> str:
    """Minúsculas e sem acentos, para a busca ignorar caixa e acentuação.

    'Comunicação' -> 'comunicacao'
    """
    decomposto = unicodedata.normalize("NFD", texto)
    sem_acentos = "".join(c for c in decomposto if not unicodedata.combining(c))
    return sem_acentos.casefold()


# --------------------------------------------------------------------------
# Trie
# --------------------------------------------------------------------------
class No:
    """Nó da Trie: um caractere do caminho, seus filhos e (se for fim de termo) os registros."""

    __slots__ = ("filhos", "eh_fim", "registros")

    def __init__(self) -> None:
        self.filhos: dict[str, No] = {}   # caractere -> próximo nó
        self.eh_fim = False               # True se um termo termina aqui
        self.registros: list[dict] = []   # registros cujo termo termina aqui


class Trie:
    def __init__(self) -> None:
        self.raiz = No()

    def inserir(self, registro: dict) -> None:
        """Insere o termo do registro: custo proporcional ao tamanho do termo."""
        chave = normalizar(registro["termo"])
        if not chave:
            raise ValueError("O termo não pode ser vazio.")
        no = self.raiz
        for caractere in chave:
            no = no.filhos.setdefault(caractere, No())
        no.eh_fim = True
        no.registros.append(registro)

    def _descer(self, texto_normalizado: str) -> No | None:
        """Segue o caminho de caracteres a partir da raiz; None se o caminho não existe."""
        no = self.raiz
        for caractere in texto_normalizado:
            no = no.filhos.get(caractere)
            if no is None:
                return None
        return no

    def buscar_exato(self, termo: str) -> list[dict]:
        no = self._descer(normalizar(termo))
        return list(no.registros) if no is not None and no.eh_fim else []

    def remover(self, registro: dict) -> bool:
        """Remove o registro da Trie (identificado pelo id) e poda os nós sem uso.

        Retorna False se o registro não estava na Trie.
        """
        caminho: list[tuple[str, No]] = []  # (caractere, nó) de cada passo da descida
        no = self.raiz
        for caractere in normalizar(registro["termo"]):
            no = no.filhos.get(caractere)
            if no is None:
                return False
            caminho.append((caractere, no))

        restantes = [r for r in no.registros if r["id"] != registro["id"]]
        if len(restantes) == len(no.registros):
            return False
        no.registros = restantes
        no.eh_fim = bool(restantes)  # só deixa de ser fim se não sobrou nenhum registro

        # Poda de baixo para cima: apaga nós que não terminam termo e não têm filhos.
        for posicao in range(len(caminho) - 1, -1, -1):
            caractere, atual = caminho[posicao]
            if atual.eh_fim or atual.filhos:
                break
            pai = caminho[posicao - 1][1] if posicao > 0 else self.raiz
            del pai.filhos[caractere]
        return True

    def buscar_prefixo(self, prefixo: str, tipo: str | None = None,
                       limite: int | None = None) -> list[dict]:
        """Todos os registros cujo termo começa com `prefixo`, em ordem alfabética."""
        no = self._descer(normalizar(prefixo.lstrip()))
        if no is None:
            return []
        return self._coletar(no, tipo, limite)

    @staticmethod
    def _coletar(inicio: No, tipo: str | None, limite: int | None) -> list[dict]:
        """Percorre a subárvore (DFS iterativa) coletando os termos completos."""
        resultados: list[dict] = []
        pilha = [inicio]
        while pilha:
            no = pilha.pop()
            if no.eh_fim:
                for registro in no.registros:
                    if tipo is None or registro["tipo"] == tipo:
                        resultados.append(registro)
                        if limite is not None and len(resultados) >= limite:
                            return resultados
            # filhos empilhados em ordem inversa => saem em ordem alfabética
            for caractere in sorted(no.filhos, reverse=True):
                pilha.append(no.filhos[caractere])
        return resultados


# --------------------------------------------------------------------------
# Tabela de registros (registros.json) + Trie, funcionando em conjunto
# --------------------------------------------------------------------------
class RepositorioRegistros:
    def __init__(self, caminho: str | Path = ARQUIVO_PADRAO) -> None:
        self.caminho = Path(caminho)
        self.registros: list[dict] = []
        self.trie = Trie()
        self.carregar()

    # --- leitura ---------------------------------------------------------
    def carregar(self) -> None:
        registros: list[dict] = []
        if self.caminho.exists():
            try:
                dados = json.loads(self.caminho.read_text(encoding="utf-8"))
            except json.JSONDecodeError as erro:
                raise ValueError(f"{self.caminho.name} não é um JSON válido: {erro}") from erro
            if not isinstance(dados, dict) or not isinstance(dados.get("registros"), list):
                raise ValueError(f"{self.caminho.name} deve ter a chave 'registros' com uma lista.")
            registros = dados["registros"]

        trie = Trie()
        ids_vistos: set[int] = set()
        for posicao, registro in enumerate(registros, start=1):
            self._validar(registro, posicao)
            if registro["id"] in ids_vistos:
                raise ValueError(f"Registro #{posicao}: 'id' {registro['id']} repetido.")
            ids_vistos.add(registro["id"])
            trie.inserir(registro)
        self.registros = registros
        self.trie = trie

    @staticmethod
    def _validar(registro: object, posicao: int) -> None:
        if not isinstance(registro, dict):
            raise ValueError(f"Registro #{posicao}: deve ser um objeto JSON.")
        if not isinstance(registro.get("id"), int):
            raise ValueError(f"Registro #{posicao}: 'id' ausente ou não inteiro.")
        if registro.get("tipo") not in TIPOS:
            raise ValueError(f"Registro #{posicao}: 'tipo' deve ser um de {', '.join(TIPOS)}.")
        termo = registro.get("termo")
        if not isinstance(termo, str) or not termo.strip():
            raise ValueError(f"Registro #{posicao}: 'termo' ausente ou vazio.")

    # --- escrita ---------------------------------------------------------
    def salvar(self) -> None:
        """Grava o JSON de forma atômica (arquivo temporário + substituição)."""
        pasta = self.caminho.parent
        pasta.mkdir(parents=True, exist_ok=True)
        fd, temporario = tempfile.mkstemp(dir=pasta, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as arquivo:
                json.dump({"registros": self.registros}, arquivo, ensure_ascii=False, indent=2)
                arquivo.write("\n")
            os.replace(temporario, self.caminho)
        except BaseException:
            if os.path.exists(temporario):
                os.remove(temporario)
            raise

    def cadastrar(self, tipo: str, termo: str, descricao: str = "") -> dict:
        tipo = normalizar(tipo).strip()
        termo = " ".join(termo.split())  # remove espaços sobrando
        if tipo not in TIPOS:
            raise ValueError(f"Tipo inválido. Use: {', '.join(TIPOS)}.")
        if not termo:
            raise ValueError("O termo não pode ser vazio.")
        if any(r["tipo"] == tipo for r in self.trie.buscar_exato(termo)):
            raise ValueError(f"{ROTULOS[tipo]} '{termo}' já está cadastrado.")

        novo = {
            "id": max((r["id"] for r in self.registros), default=0) + 1,
            "tipo": tipo,
            "termo": termo,
            "descricao": descricao.strip(),
        }
        self.registros.append(novo)
        try:
            self.salvar()
        except BaseException:
            self.registros.pop()  # mantém lista, arquivo e Trie coerentes
            raise
        self.trie.inserir(novo)
        return novo

    def obter(self, id_registro: int) -> dict | None:
        return next((r for r in self.registros if r["id"] == id_registro), None)

    def remover(self, id_registro: int) -> dict:
        """Apaga o registro do JSON e da Trie; devolve o registro apagado."""
        registro = self.obter(id_registro)
        if registro is None:
            raise ValueError(f"Não existe registro com ID {id_registro}.")
        posicao = self.registros.index(registro)
        del self.registros[posicao]
        try:
            self.salvar()
        except BaseException:
            self.registros.insert(posicao, registro)  # desfaz: nada mudou no arquivo
            raise
        self.trie.remover(registro)
        return registro

    # --- consulta --------------------------------------------------------
    def buscar(self, prefixo: str, tipo: str | None = None,
               limite: int | None = None) -> list[dict]:
        return self.trie.buscar_prefixo(prefixo, tipo=tipo, limite=limite)


# --------------------------------------------------------------------------
# Interface de texto
# --------------------------------------------------------------------------
def formatar(registro: dict) -> str:
    descricao = f" - {registro['descricao']}" if registro.get("descricao") else ""
    return f"[{ROTULOS[registro['tipo']]}] {registro['termo']}{descricao}"


def listar_tabela(registros: list[dict]) -> None:
    if not registros:
        print("Nenhum registro cadastrado.")
        return
    print(f"{'ID':>4}  {'TIPO':<8}  {'TERMO':<28}  DESCRIÇÃO")
    for r in sorted(registros, key=lambda r: r["id"]):
        print(f"{r['id']:>4}  {ROTULOS[r['tipo']]:<8}  {r['termo']:<28}  {r.get('descricao', '')}")


# --- Busca ao vivo: as sugestões aparecem a cada tecla, sem apertar Enter ---
MAX_SUGESTOES = 8
TECLAS_FIM = {"\r", "\n", "\x1b", "\x03", "\x04"}  # Enter, Esc, Ctrl+C, Ctrl+D
TECLAS_APAGAR = {"\x7f", "\b"}                     # Backspace (Linux/macOS e Windows)
ROTULO_BUSCA = "Buscar: "


class LeitorTeclas:
    """Lê o teclado tecla a tecla (sem esperar Enter) e restaura o terminal ao sair."""

    def __enter__(self) -> "LeitorTeclas":
        if msvcrt is not None:
            os.system("")  # habilita sequências ANSI no console do Windows 10+
        else:
            self._fd = sys.stdin.fileno()
            self._antigo = termios.tcgetattr(self._fd)
            tty.setcbreak(self._fd)  # sem eco e sem esperar Enter
            self._decodificador = codecs.getincrementaldecoder("utf-8")(errors="ignore")
        return self

    def __exit__(self, *_) -> None:
        if msvcrt is None:
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._antigo)

    def ler(self) -> list[str]:
        """Espera uma entrada e devolve as teclas lidas (lista vazia para setas, F1 etc.)."""
        if msvcrt is not None:
            tecla = msvcrt.getwch()
            if tecla in ("\x00", "\xe0"):  # tecla especial: descarta o segundo código
                msvcrt.getwch()
                return []
            return [tecla]
        dados = os.read(self._fd, 64)
        if not dados or dados == b"\x1b":
            return ["\x1b"]
        if dados.startswith(b"\x1b"):  # setas e outras sequências de escape
            return []
        return list(self._decodificador.decode(dados))


def _desenhar(repo: RepositorioRegistros, prefixo: str, final: bool = False) -> None:
    """Redesenha a linha de busca e as sugestões logo abaixo dela.

    O cursor sempre volta para o fim do texto digitado; por isso, cada
    redesenho começa apagando dali para baixo.
    """
    colunas, altura = shutil.get_terminal_size((80, 24))
    maximo = max(1, min(MAX_SUGESTOES, altura - 5))

    if not prefixo.strip():
        linhas = ["  (digite para ver as sugestões)"]
    else:
        resultados = repo.buscar(prefixo, limite=maximo + 1)
        linhas = [f"  {formatar(r)}" for r in resultados[:maximo]] or ["  (nenhum resultado)"]
        if len(resultados) > maximo:
            linhas.append("  ... continue digitando para refinar")
    linhas = [linha[: colunas - 1] for linha in linhas]

    if final and not prefixo.strip():
        saida = "\r\x1b[J"  # nada foi digitado: só limpa a área de busca
    else:
        saida = "\r\x1b[J" + ROTULO_BUSCA + prefixo + "\n" + "\n".join(linhas)
        if final:
            saida += "\n"
        else:  # sobe para a linha de busca e para no fim do texto digitado
            saida += f"\x1b[{len(linhas)}A\r\x1b[{len(ROTULO_BUSCA) + len(prefixo)}C"
    sys.stdout.write(saida)
    sys.stdout.flush()


def busca_ao_vivo(repo: RepositorioRegistros) -> None:
    """A cada tecla, consulta a Trie com o prefixo atual e mostra as sugestões abaixo."""
    print("Digite para buscar (Backspace apaga; Enter ou Esc volta ao menu).")
    prefixo = ""
    with LeitorTeclas() as leitor:
        try:
            _desenhar(repo, prefixo)
            terminou = False
            while not terminou:
                tamanho_maximo = shutil.get_terminal_size((80, 24)).columns - len(ROTULO_BUSCA) - 2
                for tecla in leitor.ler():
                    if tecla in TECLAS_FIM:
                        terminou = True
                        break
                    if tecla in TECLAS_APAGAR:
                        prefixo = prefixo[:-1]
                    elif tecla.isprintable() and len(prefixo) < tamanho_maximo:
                        prefixo += tecla
                if not terminou:
                    _desenhar(repo, prefixo)
        except KeyboardInterrupt:
            pass
        _desenhar(repo, prefixo, final=True)


def _terminal_interativo() -> bool:
    """A busca ao vivo só funciona em um terminal de verdade (não em IDLE nem em arquivo/pipe)."""
    tem_leitor = msvcrt is not None or termios is not None
    return tem_leitor and sys.stdin.isatty() and sys.stdout.isatty()


def acao_buscar(repo: RepositorioRegistros) -> None:
    print("\n--- Buscar por prefixo ---")
    if _terminal_interativo():
        busca_ao_vivo(repo)
    else:
        buscar_com_enter(repo)


def buscar_com_enter(repo: RepositorioRegistros) -> None:
    """Busca simples (digita o prefixo e aperta Enter), usada quando o terminal não permite a ao vivo."""
    prefixo = input("Digite o prefixo: ")
    if not prefixo.strip():
        print("Digite ao menos um caractere.")
        return
    filtro = normalizar(input(f"Filtrar por tipo ({', '.join(TIPOS)}) ou Enter para todos: ")).strip()
    if filtro and filtro not in TIPOS:
        print("Tipo inválido.")
        return
    resultados = repo.buscar(prefixo, tipo=filtro or None)
    if not resultados:
        print("Nenhum resultado.")
        return
    print(f"\n{len(resultados)} resultado(s):")
    for registro in resultados:
        print("  " + formatar(registro))


# Pergunta exibida para o termo de cada tipo. Ao criar um tipo novo,
# acrescente-o aqui, em TIPOS, em ROTULOS e em OPCOES_MENU.
PERGUNTA_TERMO = {
    "modulo": "Nome do módulo",
    "sensor": "Código do sensor",
    "comando": "Nome do comando",
    "alerta": "Palavra-chave do alerta",
}


def acao_cadastrar(repo: RepositorioRegistros, tipo: str) -> None:
    print(f"\n--- Cadastrar {ROTULOS[tipo].lower()} ---")
    termo = input(f"{PERGUNTA_TERMO[tipo]}: ")
    descricao = input("Descrição (opcional): ")
    try:
        novo = repo.cadastrar(tipo, termo, descricao)
    except ValueError as erro:
        print(f"Não cadastrado: {erro}")
    except OSError as erro:
        print(f"Não foi possível gravar o arquivo: {erro}")
    else:
        print(f"Cadastrado: {formatar(novo)}")


def acao_listar(repo: RepositorioRegistros) -> None:
    print("\n--- Todos os registros ---")
    listar_tabela(repo.registros)


def acao_remover(repo: RepositorioRegistros) -> None:
    print("\n--- Deletar registro ---")
    if not repo.registros:
        print("Nenhum registro cadastrado.")
        return
    listar_tabela(repo.registros)
    entrada = input("\nID do registro a deletar (Enter para cancelar): ").strip()
    if not entrada:
        print("Operação cancelada.")
        return
    try:
        id_registro = int(entrada)
    except ValueError:
        print("ID inválido: digite apenas números.")
        return
    registro = repo.obter(id_registro)
    if registro is None:
        print(f"Não existe registro com ID {id_registro}.")
        return
    if input(f"Deletar {formatar(registro)}? (s/n): ").strip().lower() != "s":
        print("Operação cancelada.")
        return
    try:
        repo.remover(id_registro)
    except OSError as erro:
        print(f"Não foi possível gravar o arquivo: {erro}")
    else:
        print(f"Deletado: {formatar(registro)}")


# Opções do menu: (número, texto exibido, função chamada com o repositório).
# Para mudar o menu (incluir, remover ou reordenar opções), edite só esta lista.
OPCOES_MENU = [
    ("1", "Cadastrar módulo", lambda repo: acao_cadastrar(repo, "modulo")),
    ("2", "Cadastrar sensor", lambda repo: acao_cadastrar(repo, "sensor")),
    ("3", "Cadastrar comando", lambda repo: acao_cadastrar(repo, "comando")),
    ("4", "Cadastrar alerta", lambda repo: acao_cadastrar(repo, "alerta")),
    ("5", "Buscar por prefixo", acao_buscar),
    ("6", "Listar todos os registros", acao_listar),
    ("7", "Deletar registro", acao_remover),
]
OPCAO_SAIR = "0"


def exibir_menu() -> None:
    print("\n===== SISTEMA DE BUSCA COM TRIE =====")
    for numero, texto, _ in OPCOES_MENU:
        print(f"{numero} - {texto}")
    print(f"{OPCAO_SAIR} - Sair")


def menu(repo: RepositorioRegistros) -> None:
    acoes = {numero: funcao for numero, _, funcao in OPCOES_MENU}
    while True:
        exibir_menu()
        try:
            opcao = input("Escolha uma opção: ").strip()
            if opcao == OPCAO_SAIR:
                print("Encerrando o sistema.")
                break
            acao = acoes.get(opcao)
            if acao is None:
                print("Opção inválida.")
                continue
            acao(repo)
        except (EOFError, KeyboardInterrupt):
            print()
            break


def demo() -> None:
    """Demonstração em memória, sem tocar no registros.json."""
    trie = Trie()
    exemplos = [
        ("modulo", "Comunicação"), ("comando", "Comando"), ("modulo", "Controle"),
        ("modulo", "Energia"), ("sensor", "TMP-001"), ("sensor", "TMP-002"),
        ("sensor", "PRS-001"), ("alerta", "Falha de energia"),
    ]
    for i, (tipo, termo) in enumerate(exemplos, start=1):
        trie.inserir({"id": i, "tipo": tipo, "termo": termo, "descricao": ""})
    for consulta in ("co", "CO", "comunicacao", "tmp-", "f", "xyz"):
        print(f'Digite: {consulta}')
        resultados = trie.buscar_prefixo(consulta)
        print("  " + (", ".join(r["termo"] for r in resultados) or "(sem resultados)"))


def main(argumentos: list[str]) -> int:
    if "--demo" in argumentos:
        demo()
        return 0
    try:
        repo = RepositorioRegistros()
    except ValueError as erro:
        print(f"Erro ao carregar os registros: {erro}")
        return 1
    menu(repo)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
